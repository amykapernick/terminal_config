# Astro + [Vitest](https://vitest.dev/) Example

```
npm create astro@latest -- --template with-vitest
```

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/withastro/astro/tree/latest/examples/with-vitest)
[![Open with CodeSandbox](https://assets.codesandbox.io/github/button-edit-lime.svg)](https://codesandbox.io/s/github/withastro/astro/tree/latest/examples/with-vitest)

This example showcases Astro working with [Vitest](https://vitest.dev/).

# Astro + AlpineJS Example

```
npm create astro@latest -- --template framework-alpine
```

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/withastro/astro/tree/latest/examples/framework-alpine)
[![Open with CodeSandbox](https://assets.codesandbox.io/github/button-edit-lime.svg)](https://codesandbox.io/s/github/withastro/astro/tree/latest/examples/framework-alpine)

This example showcases Astro working with [AlpineJS](https://alpinejs.dev/).


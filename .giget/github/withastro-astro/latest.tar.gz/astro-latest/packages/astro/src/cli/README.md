# `cli/`

Code that controls Astro’s binfile and is responsible for `astro *` CLI commands.

[See CONTRIBUTING.md](../../../../CONTRIBUTING.md) for a code overview.

# `@types/`

TypeScript definitions and types for untyped modules.

[See CONTRIBUTING.md](../../../../CONTRIBUTING.md) for a code overview.

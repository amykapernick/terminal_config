import 'solid-js';

export default function SolidComponent({ id }) {
	return (
		<div id={id}>Framework client:only component</div>
	);
}

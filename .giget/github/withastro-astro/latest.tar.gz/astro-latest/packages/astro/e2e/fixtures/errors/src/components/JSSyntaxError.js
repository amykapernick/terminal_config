export default function Error() {
  const 1badvar = true;
  return 1badvar;
}

export { default as A } from './A.astro';
export { default as B } from './B.astro';

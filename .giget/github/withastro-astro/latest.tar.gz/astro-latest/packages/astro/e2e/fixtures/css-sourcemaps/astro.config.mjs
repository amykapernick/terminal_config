export default {
	vite: {
		css: {
			devSourcemap: true,
		}
	}
};

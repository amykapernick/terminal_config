# benchmark

Astro's main benchmark suite. It exposes the `astro-benchmark` CLI command. Run `astro-benchmark --help` to see all available commands!

If you'd like to understand how the benchmark works, check out the other READMEs in the subfolders.
